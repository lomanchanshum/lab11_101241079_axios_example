import logo from './logo.svg';
import './App.css';
import PersonList from './PersonList';

function App() {
  return (
    <>
    <PersonList/>
    </>
  );
}

export default App;
